package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WorkoutController {

    @GetMapping("/workout-track")
    public String workoutTrack() {
        return "workout-track";
    }
}

